package com.example.glasslauncher

import android.content.Context

class Prefs(ctx: Context) {

    class Setting(
        val key: String,
        val label: String,
        val min: Int,
        val max: Int,
        val def: Int,
        val unit: String
    )

    class BoolSetting(val key: String, val label: String, val def: Boolean)

    companion object {
        val ALL = listOf(
            Setting("speed", "Animation speed", 50, 200, 100, "%"),
            Setting("blur", "Blur strength", 0, 60, 30, ""),
            Setting("bounce", "Spring bounciness", 0, 100, 50, "%"),
            Setting("iconSize", "Icon size", 40, 72, 56, " dp"),
            Setting("round", "Icon roundness", 0, 50, 32, "%"),
            Setting("cols", "Grid columns", 4, 6, 5, ""),
            Setting("rows", "Grid rows", 4, 7, 6, "")
        )

        val BOOLS = listOf(
            BoolSetting("showLabels", "Show names under home icons", true),
            BoolSetting("showDrawerLabels", "Show names in the app drawer", true)
        )
    }

    private val sp = ctx.applicationContext.getSharedPreferences("glass", Context.MODE_PRIVATE)

    fun get(key: String): Int = sp.getInt(key, ALL.first { it.key == key }.def)

    fun put(key: String, v: Int) {
        sp.edit().putInt(key, v).apply()
    }

    fun getStr(key: String, def: String): String = sp.getString(key, def) ?: def

    fun putStr(key: String, v: String) {
        sp.edit().putString(key, v).apply()
    }

    fun getBool(key: String): Boolean {
        // Keep the original SettingsActivity preference key working while newer home code
        // uses the shorter showLabels name.
        val canonical = when (key) {
            "showHomeLabels" -> "showLabels"
            else -> key
        }
        val def = when (canonical) {
            "showLabels", "showDrawerLabels" -> true
            else -> false
        }
        return sp.getBoolean(canonical, sp.getBoolean(key, def))
    }

    fun putBool(key: String, v: Boolean) {
        val canonical = when (key) {
            "showHomeLabels" -> "showLabels"
            else -> key
        }
        sp.edit().putBoolean(canonical, v).putBoolean(key, v).apply()
    }

    // Compatibility for HomeActivity's generic integer preference API.
    fun getInt(key: String, def: Int): Int = when (key) {
        "homePageCount" -> homePageCount()
        else -> sp.getInt(key, def)
    }

    fun putInt(key: String, value: Int) {
        if (key == "homePageCount") setHomePageCount(value)
        else sp.edit().putInt(key, value.coerceAtLeast(1)).apply()
    }

    /** Internal one-off flags (e.g. "ran this once") that aren't part of the settings screen. */
    fun getFlag(key: String, def: Boolean = false): Boolean = sp.getBoolean(key, def)

    fun setFlag(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    /** Home screen pages the user has explicitly created, on top of whatever items already force into being. */
    fun homePageCount(): Int = sp.getInt("homePageCount", 1).coerceAtLeast(1)

    fun setHomePageCount(v: Int) {
        sp.edit().putInt("homePageCount", v.coerceAtLeast(1)).apply()
    }

    /** Resets the sliders only. Your home layout is kept. */
    fun reset() {
        val e = sp.edit()
        for (s in ALL) e.remove(s.key)
        for (s in BOOLS) e.remove(s.key)
        e.remove("showHomeLabels")
        e.apply()
    }

    fun blurPx(): Float = get("blur").toFloat()

    /** 0.95 = firm, 0.45 = bouncy */
    fun damping(): Float = 0.95f - 0.5f * get("bounce") / 100f

    fun stiffness(): Float {
        val s = get("speed") / 100f
        return 500f * s * s
    }

    /** Scale a base duration by the speed setting. */
    fun ms(base: Long): Long = base * 100L / get("speed")
}
