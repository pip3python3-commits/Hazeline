package com.example.glasslauncher

import android.graphics.RenderEffect
import android.graphics.Shader
import android.view.Choreographer
import android.view.View
import android.view.ViewGroup
import kotlin.math.abs
import kotlin.math.sqrt

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Blur a view's own pixels (Android 12+). Radius under 0.5 removes the effect. */
fun View.setBlur(radius: Float) {
    if (radius < 0.5f) {
        setRenderEffect(null)
    } else {
        setRenderEffect(RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP))
    }
}

/** Which view property a spring animates — a tiny stand-in for the old AndroidX enum. */
enum class SpringProp { TRANSLATION_X, TRANSLATION_Y, SCALE_X, SCALE_Y }

private fun SpringProp.getOn(v: View): Float = when (this) {
    SpringProp.TRANSLATION_X -> v.translationX
    SpringProp.TRANSLATION_Y -> v.translationY
    SpringProp.SCALE_X -> v.scaleX
    SpringProp.SCALE_Y -> v.scaleY
}

private fun SpringProp.setOn(v: View, value: Float) {
    when (this) {
        SpringProp.TRANSLATION_X -> v.translationX = value
        SpringProp.TRANSLATION_Y -> v.translationY = value
        SpringProp.SCALE_X -> v.scaleX = value
        SpringProp.SCALE_Y -> v.scaleY = value
    }
}

/**
 * Spring-animate one property of a view using the speed/bounce settings. A small hand-rolled
 * damped-harmonic-oscillator stepper, frame-driven via Choreographer, so the same springy motion
 * runs with no external physics library.
 */
fun View.spring(
    prop: SpringProp,
    to: Float,
    prefs: Prefs,
    delay: Long = 0L,
    onEnd: (() -> Unit)? = null
) {
    val view = this
    val go = Runnable {
        val stiffness = prefs.stiffness().coerceAtLeast(10f)
        val dampingRatio = prefs.damping()
        val dampingCoef = dampingRatio * 2f * sqrt(stiffness.toDouble()).toFloat()
        var velocity = 0f
        var value = prop.getOn(view)
        var lastTime = System.nanoTime()
        val isScale = prop == SpringProp.SCALE_X || prop == SpringProp.SCALE_Y
        val posEps = if (isScale) 0.001f else 0.05f
        val velEps = if (isScale) 0.002f else 0.08f

        lateinit var frame: Choreographer.FrameCallback
        frame = Choreographer.FrameCallback { now ->
            val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, 0.032f)
            lastTime = now
            val force = -stiffness * (value - to) - dampingCoef * velocity
            velocity += force * dt
            value += velocity * dt
            prop.setOn(view, value)
            if (abs(value - to) < posEps && abs(velocity) < velEps) {
                prop.setOn(view, to)
                onEnd?.invoke()
            } else {
                Choreographer.getInstance().postFrameCallback(frame)
            }
        }
        Choreographer.getInstance().postFrameCallback(frame)
    }
    if (delay > 0L) view.postDelayed(go, delay) else go.run()
}

fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
