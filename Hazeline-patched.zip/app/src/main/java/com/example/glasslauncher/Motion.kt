package com.example.glasslauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Latest picture of each app you used, kept in memory only. */
object SnapshotStore {
    private val map = LinkedHashMap<String, Bitmap>()

    @Synchronized
    fun put(pkg: String, b: Bitmap) {
        map.remove(pkg)
        map[pkg] = b
        while (map.size > 8) map.remove(map.keys.first())
    }

    @Synchronized
    fun get(pkg: String): Bitmap? = map[pkg]
}

/** Lets the motion service and the home screen talk to each other. */
object HomeBridge {
    var iconRect: ((String) -> Rect?)? = null
    val lastLaunchRect = HashMap<String, Rect>()
}

/**
 * Draws an app (its snapshot, or a coloured card with its icon) shrinking into / growing out of an icon.
 * t = 0: full screen.  t = 1: sitting on the icon.  The shape narrows toward the bottom like a funnel.
 */
class MotionOverlay(ctx: Context) : View(ctx) {
    var snapshot: Bitmap? = null
    var icon: Bitmap? = null
    var color: Int = Color.DKGRAY
    var iconRect = RectF()
    var radiusIcon = 0f
    var radiusScreen = 0f
    var funnelMax = 0.16f
    var t = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val mw = 6
    private val mh = 10
    private val verts = FloatArray((mw + 1) * (mh + 1) * 2)
    private val meshPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Path()
    private val pts = FloatArray(8)

    init {
        clearPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val l = lerp(0f, iconRect.left, t)
        val top = lerp(0f, iconRect.top, t)
        val r = lerp(w, iconRect.right, t)
        val b = lerp(h, iconRect.bottom, t)
        val f = funnelMax * sin(PI * t).toFloat()
        val cx = (l + r) / 2f
        val half = (r - l) / 2f
        val halfB = half * (1f - f)
        val rad = lerp(radiusScreen, radiusIcon, t)

        pts[0] = l; pts[1] = top
        pts[2] = r; pts[3] = top
        pts[4] = cx + halfB; pts[5] = b
        pts[6] = cx - halfB; pts[7] = b
        roundedPolygon(pts, rad, outline)
        outline.fillType = Path.FillType.INVERSE_WINDING

        val layer = c.saveLayer(0f, 0f, w, h, null)
        val bmp = snapshot
        if (bmp != null) {
            var k = 0
            for (j in 0..mh) {
                val v = j / mh.toFloat()
                val y = top + (b - top) * v
                val hw = half * (1f - f * v)
                for (i in 0..mw) {
                    val u = i / mw.toFloat()
                    verts[k++] = cx + (u - 0.5f) * 2f * hw
                    verts[k++] = y
                }
            }
            c.drawBitmapMesh(bmp, mw, mh, verts, 0, null, 0, meshPaint)
        } else {
            fillPaint.color = color
            c.drawRect(l, top, r, b, fillPaint)
            val ic = icon
            if (ic != null) {
                val size = lerp(iconRect.width(), 96f * resources.displayMetrics.density, 1f - t)
                val a = (1f - (1f - t) * 1.6f).coerceIn(0f, 1f)
                fillPaint.alpha = (255 * a).toInt()
                val dst = RectF(cx - size / 2f, (top + b) / 2f - size / 2f, cx + size / 2f, (top + b) / 2f + size / 2f)
                c.drawBitmap(ic, null, dst, fillPaint)
                fillPaint.alpha = 255
            }
        }
        c.drawPath(outline, clearPaint)
        c.restoreToCount(layer)
    }

    private fun roundedPolygon(p: FloatArray, r: Float, out: Path) {
        out.reset()
        val n = p.size / 2
        for (i in 0 until n) {
            val px = p[i * 2]
            val py = p[i * 2 + 1]
            val ai = (i + n - 1) % n
            val bi = (i + 1) % n
            val ax = p[ai * 2]
            val ay = p[ai * 2 + 1]
            val bx = p[bi * 2]
            val by = p[bi * 2 + 1]
            val d1 = hypot(ax - px, ay - py).coerceAtLeast(1f)
            val d2 = hypot(bx - px, by - py).coerceAtLeast(1f)
            val rr = min(r, min(d1, d2) / 2f)
            val p1x = px + (ax - px) / d1 * rr
            val p1y = py + (ay - py) / d1 * rr
            val p2x = px + (bx - px) / d2 * rr
            val p2y = py + (by - py) / d2 * rr
            if (i == 0) out.moveTo(p1x, p1y) else out.lineTo(p1x, p1y)
            out.quadTo(px, py, p2x, p2y)
        }
        out.close()
    }
}
