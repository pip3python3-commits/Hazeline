package com.example.glasslauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.KeyguardManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.ceil
import kotlin.math.hypot

private class Slot(val page: Int, val x: Int, val y: Int)

class HomeActivity : AppCompatActivity() {

    companion object {
        const val REQ_BIND = 41
        const val REQ_CONFIG = 42
        const val HOST_ID = 1024
        const val SRC_HOME = 0
        const val SRC_DOCK = 1
        const val SRC_DRAWER = 2
    }

    private lateinit var prefs: Prefs
    private lateinit var launcherApps: LauncherApps
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var root: GestureFrame
    private lateinit var homeLayer: LinearLayout
    private lateinit var pager: HomePager
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var scrim: View
    private lateinit var shade: ShadeView
    private lateinit var drawer: LinearLayout
    private lateinit var drawerSearch: EditText
    private lateinit var drawerScroll: ScrollView
    private lateinit var card: FrameLayout
    private lateinit var cardIcon: ImageView
    private val cardBg = GradientDrawable()

    private var apps: List<AppInfo> = emptyList()
    private var appByKey: Map<String, AppInfo> = emptyMap()
    private var items: MutableList<HomeItem> = ArrayList()
    private var dockApps: List<AppInfo> = emptyList()
    private val iconViews = HashMap<String, ImageView>()

    private var resumed = false
    private var awaitingReturn = false
    private var awaitingPkg: String? = null
    private var shadeOpen = false
    private var drawerOpen = false
    private var loading = false
    private var builtSig = ""
    private var depth = 0f
    private var pinch = 1f
    private var needBurst = true
    private var pollingBurst = false
    private var pollTries = 0
    private var lastBurst = 0L
    private var insetTop = 0
    private var insetBottom = 0
    private var pendingWidgetId = -1
    private var pendingProvider: AppWidgetProviderInfo? = null
    private val ui = Handler(Looper.getMainLooper())
    private val keyguard by lazy { getSystemService(KeyguardManager::class.java)!! }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        launcherApps = getSystemService(LauncherApps::class.java)!!
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setBackgroundDrawable(ColorDrawable(0x01000000))
        buildUi()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) {
                    closeDrawer(true)
                } else if (shadeOpen) {
                    val svc = HazelineService.instance
                    val activeShade = if (svc != null && svc.isShadeShown()) svc.shadeView() else shade
                    if (activeShade?.showingQs == true) activeShade.showPage(false) else closeShade()
                }
            }
        })

        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        launcherApps.registerCallback(pkgCallback)
        HomeBridge.iconRect = { pkg -> findIconRect(pkg) }
        applyDefaultWallpaperOnce()
    }

    /** Sets the bundled Hazeline wallpaper once, the first time the launcher ever runs. */
    private fun applyDefaultWallpaperOnce() {
        if (prefs.getFlag("wallpaperApplied")) return
        Thread {
            try {
                val bmp = BitmapFactory.decodeResource(resources, R.drawable.wallpaper_default)
                if (bmp != null) {
                    android.app.WallpaperManager.getInstance(this).setBitmap(bmp)
                }
            } catch (e: Exception) {
            } finally {
                runOnUiThread { prefs.setFlag("wallpaperApplied", true) }
            }
        }.start()
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        HazelineService.depthListener = { t -> setDepth(t) }
        HazelineService.shadeShownListener = { shown -> shadeOpen = shown }
        shadeOpen = HazelineService.instance?.isShadeShown() ?: shadeOpen
        if (builtSig != currentSig()) reload()
        if (needBurst) {
            startBurstPoll()
        } else if (awaitingReturn) {
            val pkg = awaitingPkg
            awaitingReturn = false
            awaitingPkg = null
            playReturn(pkg)
        } else if (card.visibility == View.VISIBLE) {
            card.visibility = View.GONE
            setDepth(if (shadeOpen) 1f else 0f)
        }
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        HazelineService.depthListener = null
        HazelineService.shadeShownListener = null
    }

    override fun onDestroy() {
        super.onDestroy()
        HomeBridge.iconRect = null
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        launcherApps.unregisterCallback(pkgCallback)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!shadeOpen && !drawerOpen) scaleDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------ receivers

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (!shadeOpen && !drawerOpen) {
                        needBurst = true
                        for (v in allAnimViews()) v.alpha = 0f
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    if (needBurst) startBurstPoll()
                }
            }
        }
    }

    private val pkgCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(p: String?, u: UserHandle?) {
            appsChanged()
        }

        override fun onPackageAdded(p: String?, u: UserHandle?) {
            appsChanged()
        }

        override fun onPackageChanged(p: String?, u: UserHandle?) {
            appsChanged()
        }

        override fun onPackagesAvailable(p: Array<out String>?, u: UserHandle?, replacing: Boolean) {
            appsChanged()
        }

        override fun onPackagesUnavailable(p: Array<out String>?, u: UserHandle?, replacing: Boolean) {
            appsChanged()
        }
    }

    private fun appsChanged() {
        IconCache.clear(this)
        reload()
    }

    // ------------------------------------------------------------ UI building

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun glass(color: String, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun buildUi() {
        root = GestureFrame(this)
        homeLayer = LinearLayout(this)
        homeLayer.orientation = LinearLayout.VERTICAL
        homeLayer.clipChildren = false
        homeLayer.clipToPadding = false

        pager = HomePager(this)

        dots = DotsView(this)
        pager.onScrollProgress = { t -> dots.index = t }

        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.clipChildren = false
        dock.background = glass("#33FFFFFF", 30)
        dock.setPadding(dp(8), dp(10), dp(8), dp(10))

        homeLayer.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))
        homeLayer.addView(dots, LinearLayout.LayoutParams(MATCH, dp(14)))
        val dockLp = LinearLayout.LayoutParams(MATCH, WRAP)
        dockLp.setMargins(dp(14), dp(6), dp(14), dp(10))
        homeLayer.addView(dock, dockLp)

        scrim = View(this)
        scrim.setBackgroundColor(Color.BLACK)
        scrim.alpha = 0f

        buildDrawer()

        shade = ShadeView(this, prefs, object : ShadeView.Host {
            override fun close() {
                closeShade()
            }

            override fun settings() {
                closeShade()
                startActivity(Intent(this@HomeActivity, SettingsActivity::class.java))
            }
        })

        card = FrameLayout(this)
        card.background = cardBg
        card.visibility = View.GONE
        cardIcon = ImageView(this)
        card.addView(cardIcon, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))

        root.addView(homeLayer, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(shade, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(card, FrameLayout.LayoutParams(1, 1))
        root.onSwipeDown = { openShade(false) }
        root.onSwipeUp = { openDrawer() }
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            insetTop = b.top
            insetBottom = b.bottom
            homeLayer.setPadding(0, b.top + dp(10), 0, b.bottom)
            drawer.setPadding(0, b.top + dp(10), 0, b.bottom)
            shade.setInsets(b.top, b.bottom)
            insets
        }
    }

    private fun buildDrawer() {
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.visibility = View.GONE

        drawerSearch = EditText(this)
        drawerSearch.hint = "Search apps"
        drawerSearch.setHintTextColor(Color.parseColor("#B3FFFFFF"))
        drawerSearch.setTextColor(Color.WHITE)
        drawerSearch.textSize = 16f
        drawerSearch.setSingleLine(true)
        drawerSearch.background = glass("#44FFFFFF", 26)
        drawerSearch.setPadding(dp(20), 0, dp(20), 0)
        drawerSearch.imeOptions = EditorInfo.IME_ACTION_SEARCH
        drawerSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}

            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}

            override fun afterTextChanged(s: Editable?) {
                fillDrawer(s?.toString() ?: "")
            }
        })
        drawerSearch.setOnEditorActionListener { _, _, _ ->
            val q = drawerSearch.text.toString().trim()
            val hit = if (q.isEmpty()) null else apps.filter { it.label.contains(q, true) }.singleOrNull()
            if (hit != null) {
                launch(hit, drawerSearch)
            }
            true
        }
        val sl = LinearLayout.LayoutParams(MATCH, dp(50))
        sl.setMargins(dp(18), dp(6), dp(18), dp(10))
        drawer.addView(drawerSearch, sl)

        drawerScroll = ScrollView(this)
        drawerScroll.overScrollMode = View.OVER_SCROLL_NEVER
        drawer.addView(drawerScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    // ------------------------------------------------------------ loading apps

    private fun currentSig(): String =
        listOf("iconSize", "round", "cols", "rows").joinToString(",") { prefs.get(it).toString() }

    private fun reload() {
        if (loading) return
        loading = true
        val sig = currentSig()
        val px = dp(prefs.get("iconSize"))
        val round = prefs.get("round")
        val dens = resources.displayMetrics.densityDpi
        val ctx = applicationContext
        Thread {
            try {
                val profiles = try {
                    launcherApps.profiles.ifEmpty { listOf(Process.myUserHandle()) }
                } catch (e: Exception) {
                    listOf(Process.myUserHandle())
                }
                val list = profiles.flatMap { u ->
                    try {
                        launcherApps.getActivityList(null, u)
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
                    .filter { it.componentName.packageName != packageName }
                    .map { AppInfo(it) }
                    .sortedBy { it.label.lowercase() }
                val byKey = HashMap<String, AppInfo>()
                for (a in list) {
                    byKey[a.key] = a
                    // Preserve homes saved by older builds before user-profile identity was
                    // appended to the key. This prevents existing icons from disappearing.
                    byKey.putIfAbsent(a.component.flattenToString(), a)
                }
                val dockPick = pickDock(list)

                // first run: put the first page of apps on the home screen
                if (!HomeStore.seeded(prefs) && list.isNotEmpty()) {
                    HomeStore.save(prefs, seedHome(list, dockPick))
                    HomeStore.markSeeded(prefs)
                }
                val loaded = HomeStore.load(prefs)
                    .filter { it.kind != "app" || byKey.containsKey(it.key) }
                    .map { item ->
                        // Upgrade old component-only app keys to the profile-aware key.
                        val app = if (item.kind == "app") byKey[item.key] else null
                        if (app != null && item.key != app.key) {
                            HomeItem(item.kind, app.key, item.page, item.x, item.y, item.sx, item.sy)
                        } else item
                    }

                // phase 1: only what the home screen needs, so it appears fast
                val needed = HashSet<String>()
                for (it in loaded) if (it.kind == "app") needed.add(it.key)
                for (a in dockPick) needed.add(a.key)
                for (a in list) {
                    if (needed.contains(a.key)) a.icon = IconCache.get(ctx, a, px, round, dens)
                }
                runOnUiThread {
                    apps = list
                    appByKey = byKey
                    dockApps = dockPick
                    items = loaded.toMutableList()
                    if (builtSig != sig) reflowIfGridChanged()
                    builtSig = sig
                    layoutHome()
                }
                // phase 2: the rest, for the drawer
                for (a in list) {
                    if (a.icon == null) a.icon = IconCache.get(ctx, a, px, round, dens)
                }
                runOnUiThread {
                    loading = false
                    if (drawerOpen) fillDrawer(drawerSearch.text.toString())
                }
            } catch (e: Exception) {
                runOnUiThread { loading = false }
            }
        }.start()
    }

    private fun pickDock(all: List<AppInfo>): List<AppInfo> {
        val groups = listOf(
            listOf("com.samsung.android.dialer", "com.google.android.dialer", "com.android.dialer"),
            listOf("com.samsung.android.messaging", "com.google.android.apps.messaging"),
            listOf("com.sec.android.app.sbrowser", "com.android.chrome"),
            listOf("com.sec.android.app.camera", "com.android.camera2")
        )
        val out = ArrayList<AppInfo>()
        for (g in groups) {
            val hit = all.firstOrNull { a -> a.component.packageName in g && out.none { it === a } }
            if (hit != null) out.add(hit)
        }
        for (a in all) {
            if (out.size >= 4) break
            if (out.none { it === a }) out.add(a)
        }
        return out
    }

    private fun seedHome(list: List<AppInfo>, dockPick: List<AppInfo>): List<HomeItem> {
        val cols = prefs.get("cols")
        val rows = prefs.get("rows")
        val cap = cols * rows
        val rest = list.filter { a -> dockPick.none { it === a } }.take(cap)
        val out = ArrayList<HomeItem>()
        rest.forEachIndexed { i, a ->
            out.add(HomeItem("app", a.key, 0, i % cols, i / cols, 1, 1))
        }
        return out
    }

    /** If you change the grid size in settings, lay everything out again so nothing is off-grid. */
    private fun reflowIfGridChanged() {
        val cols = prefs.get("cols")
        val rows = prefs.get("rows")
        val bad = items.any { it.x + it.sx > cols || it.y + it.sy > rows }
        if (!bad) return
        val old = ArrayList(items)
        items.clear()
        for (it in old) {
            if (it.kind == "widget") {
                it.sx = it.sx.coerceAtMost(cols)
                it.sy = it.sy.coerceAtMost(rows)
            }
        }
        for (it in old) {
            val s = findFree(it.sx, it.sy) ?: continue
            it.page = s.page
            it.x = s.x
            it.y = s.y
            items.add(it)
        }
        HomeStore.save(prefs, items)
    }

    // ------------------------------------------------------------ home grid

    private fun pageCount(): Int = maxOf((items.maxOfOrNull { it.page } ?: -1) + 1, prefs.homePageCount())

    private fun findFree(sx: Int, sy: Int): Slot? {
        val cols = prefs.get("cols")
        val rows = prefs.get("rows")
        for (p in 0..pageCount()) {
            val occ = Array(rows) { BooleanArray(cols) }
            for (item in items) {
                if (item.page != p) continue
                for (yy in item.y until minOf(rows, item.y + item.sy)) {
                    for (xx in item.x until minOf(cols, item.x + item.sx)) occ[yy][xx] = true
                }
            }
            for (y in 0..(rows - sy)) {
                for (x in 0..(cols - sx)) {
                    var ok = true
                    for (yy in y until y + sy) {
                        for (xx in x until x + sx) if (occ[yy][xx]) ok = false
                    }
                    if (ok) return Slot(p, x, y)
                }
            }
        }
        return null
    }

    /** Whether [item] could occupy a [newSx]x[newSy] box at its current spot without covering a sibling. */
    private fun fitsAt(item: HomeItem, newSx: Int, newSy: Int): Boolean {
        val cols = prefs.get("cols")
        val rows = prefs.get("rows")
        if (item.x + newSx > cols || item.y + newSy > rows) return false
        for (other in items) {
            if (other === item || other.page != item.page) continue
            val ox1 = other.x; val ox2 = other.x + other.sx
            val oy1 = other.y; val oy2 = other.y + other.sy
            val nx1 = item.x; val nx2 = item.x + newSx
            val ny1 = item.y; val ny2 = item.y + newSy
            val overlap = nx1 < ox2 && nx2 > ox1 && ny1 < oy2 && ny2 > oy1
            if (overlap) return false
        }
        return true
    }

    /** Builds one GridPage view fully populated for [position]. */
    private fun buildPageView(position: Int): GridPage {
        val g = GridPage(this, prefs.get("cols"), prefs.get("rows"))
        g.clipChildren = false
        g.setOnLongClickListener {
            showHomeMenu()
            true
        }
        for (item in items) {
            if (item.page != position) continue
            val lp = GridPage.Lp(item.x, item.y, item.sx, item.sy)
            val v: View? = if (item.kind == "app") {
                val app = appByKey[item.key]
                if (app == null) null else makeCell(app, prefs.getBool("showLabels"), SRC_HOME)
            } else {
                makeWidgetView(item, g)
            }
            if (v != null) {
                if (needBurst) v.alpha = 0f
                g.addView(v, lp)
            }
        }
        return g
    }

    private fun buildAllPages(): List<GridPage> = (0 until pageCount()).map { buildPageView(it) }

    private fun layoutHome() {
        val keep = pager.currentItem
        pager.setPages(buildAllPages(), if (keep in 0 until pageCount()) keep else 0)
        dots.count = pageCount()
        dock.removeAllViews()
        for (a in dockApps) {
            val c = makeCell(a, false, SRC_DOCK)
            dock.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        if (drawerOpen) fillDrawer(drawerSearch.text.toString())
    }

    private fun rebuildPages(goTo: Int) {
        HomeStore.save(prefs, items)
        val target = goTo.coerceAtMost(pageCount() - 1).coerceAtLeast(0)
        pager.setPages(buildAllPages(), target)
        dots.count = pageCount()
    }

    private fun makeCell(app: AppInfo, label: Boolean, source: Int): View {
        val sz = dp(prefs.get("iconSize"))
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER
        cell.clipChildren = false
        cell.tag = app.component.packageName
        val iv = ImageView(this)
        iv.setImageBitmap(app.icon)
        cell.addView(iv, LinearLayout.LayoutParams(sz, sz))
        if (label) {
            val tv = TextView(this)
            tv.text = app.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11.5f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            tv.setShadowLayer(6f, 0f, 1f, Color.parseColor("#99000000"))
            tv.setPadding(dp(2), dp(5), dp(2), 0)
            cell.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        if (source != SRC_DRAWER) iconViews[app.component.packageName] = iv
        cell.setOnClickListener { launch(app, iv) }
        cell.setOnLongClickListener {
            showMenu(cell, app, source)
            true
        }
        return cell
    }

    private fun showMenu(anchor: View, app: AppInfo, source: Int) {
        val m = PopupMenu(this, anchor)
        if (source == SRC_HOME) m.menu.add(0, 3, 0, "Remove from Home")
        if (source == SRC_DRAWER) m.menu.add(0, 4, 0, "Add to Home")
        m.menu.add(0, 1, 1, "App info")
        m.menu.add(0, 2, 2, "Uninstall")
        m.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> launcherApps.startAppDetailsActivity(app.component, app.info.user, null, null)
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.component.packageName)))
                3 -> {
                    items.removeAll { it.kind == "app" && it.key == app.key }
                    rebuildPages(pager.currentItem)
                }
                4 -> addToHome(app)
            }
            true
        }
        m.show()
    }

    private fun addToHome(app: AppInfo) {
        if (items.any { it.kind == "app" && it.key == app.key }) {
            Toast.makeText(this, app.label + " is already on Home", Toast.LENGTH_SHORT).show()
            return
        }
        val s = findFree(1, 1)
        if (s == null) {
            Toast.makeText(this, "No space on Home", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeItem("app", app.key, s.page, s.x, s.y, 1, 1))
        rebuildPages(pager.currentItem)
        Toast.makeText(this, "Added " + app.label, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ widgets

    private fun showHomeMenu() {
        val here = pager.currentItem
        val pageEmpty = items.none { it.page == here }
        val canRemove = pageEmpty && pageCount() > 1
        val opts = buildList {
            add("Widgets")
            add("Add Home Screen")
            if (canRemove) add("Remove this Home Screen")
            add("Hazeline settings")
        }.toTypedArray()
        AlertDialog.Builder(this).setItems(opts) { _, which ->
            when (opts[which]) {
                "Widgets" -> pickWidget()
                "Add Home Screen" -> {
                    prefs.setHomePageCount(pageCount() + 1)
                    rebuildPages(pageCount() - 1)
                }
                "Remove this Home Screen" -> {
                    for (it in items) if (it.page > here) it.page -= 1
                    prefs.setHomePageCount((pageCount() - 1).coerceAtLeast(1))
                    rebuildPages(here.coerceAtMost(pageCount() - 1))
                }
                "Hazeline settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            }
        }.show()
    }

    private fun pickWidget() {
        val pm = packageManager
        val providers = widgetManager.installedProviders.sortedBy { it.loadLabel(pm).toString().lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "No widgets available", Toast.LENGTH_SHORT).show()
            return
        }
        val names = providers.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Add a widget").setItems(names) { _, which ->
            beginAddWidget(providers[which])
        }.show()
    }

    private fun beginAddWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        pendingProvider = info
        if (widgetManager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind(id, info)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun afterBind(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
                return
            } catch (e: Exception) {
            }
        }
        placeWidget(id, info)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingWidgetId
        val info = pendingProvider
        if (id < 0 || info == null) return
        if (resultCode != RESULT_OK) {
            widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            pendingProvider = null
            return
        }
        if (requestCode == REQ_BIND) afterBind(id, info)
        if (requestCode == REQ_CONFIG) placeWidget(id, info)
    }

    private fun placeWidget(id: Int, info: AppWidgetProviderInfo) {
        pendingWidgetId = -1
        pendingProvider = null
        val cols = prefs.get("cols")
        val rows = prefs.get("rows")
        val cw = (pager.width / cols).coerceAtLeast(1)
        val ch = (pager.height / rows).coerceAtLeast(1)
        val sx = ceil(info.minWidth.toFloat() / cw).toInt().coerceIn(1, cols)
        val sy = ceil(info.minHeight.toFloat() / ch).toInt().coerceIn(1, rows)
        val s = findFree(sx, sy)
        if (s == null) {
            widgetHost.deleteAppWidgetId(id)
            Toast.makeText(this, "No space for that widget", Toast.LENGTH_SHORT).show()
            return
        }
        items.add(HomeItem("widget", id.toString(), s.page, s.x, s.y, sx, sy))
        rebuildPages(s.page)
    }

    private fun makeWidgetView(item: HomeItem, page: GridPage): View? {
        val id = item.key.toIntOrNull() ?: return null
        val info = widgetManager.getAppWidgetInfo(id) ?: return null
        val hv: AppWidgetHostView = widgetHost.createView(this, id, info)
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(5), dp(5), dp(5), dp(5))
        wrap.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
        wrap.setOnLongClickListener {
            showWidgetMenu(item)
            true
        }
        hv.setOnLongClickListener {
            showWidgetMenu(item)
            true
        }
        page.post {
            val d = resources.displayMetrics.density
            val wDp = (page.width / page.cols * item.sx / d).toInt()
            val hDp = (page.height / page.rows * item.sy / d).toInt()
            try {
                hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
            } catch (e: Exception) {
            }
        }
        return wrap
    }

    private fun showWidgetMenu(item: HomeItem) {
        AlertDialog.Builder(this).setItems(arrayOf("Resize", "Remove widget")) { _, which ->
            if (which == 0) showResizeDialog(item)
            else {
                item.key.toIntOrNull()?.let { widgetHost.deleteAppWidgetId(it) }
                items.remove(item)
                rebuildPages(pager.currentItem)
            }
        }.show()
    }

    /** Minus/plus steppers for width and height, with a live preview and sibling-overlap guard. */
    private fun showResizeDialog(item: HomeItem) {
        val pad = dp(18)
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Resize widget"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        panel.addView(title)

        fun stepperRow(label: String, get: () -> Int, set: (Int) -> Unit, min: Int, max: Int): TextView {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val lbl = TextView(this)
            lbl.text = label
            lbl.setTextColor(Color.parseColor("#CCFFFFFF"))
            row.addView(lbl, LinearLayout.LayoutParams(0, WRAP, 1f))
            val value = TextView(this)
            value.setTextColor(Color.WHITE)
            value.textSize = 16f
            value.text = get().toString()
            val minus = Button(this)
            minus.text = "–"
            minus.setOnClickListener {
                val v = (get() - 1).coerceAtLeast(min)
                if (v != get() && fitsAt(item, if (label == "Width") v else item.sx, if (label == "Height") v else item.sy)) {
                    set(v)
                    value.text = get().toString()
                    rebuildPages(pager.currentItem)
                }
            }
            val plus = Button(this)
            plus.text = "+"
            plus.setOnClickListener {
                val v = (get() + 1).coerceAtMost(max)
                if (v != get() && fitsAt(item, if (label == "Width") v else item.sx, if (label == "Height") v else item.sy)) {
                    set(v)
                    value.text = get().toString()
                    rebuildPages(pager.currentItem)
                }
            }
            row.addView(minus)
            row.addView(value, LinearLayout.LayoutParams(dp(36), WRAP).also { it.gravity = Gravity.CENTER })
            row.addView(plus)
            panel.addView(row)
            return value
        }

        stepperRow("Width", { item.sx }, { item.sx = it }, 1, prefs.get("cols"))
        stepperRow("Height", { item.sy }, { item.sy = it }, 1, prefs.get("rows"))

        AlertDialog.Builder(this)
            .setView(panel)
            .setPositiveButton("Done") { _, _ -> HomeStore.save(prefs, items) }
            .setOnCancelListener { HomeStore.save(prefs, items) }
            .show()
    }

    // ------------------------------------------------------------ app drawer

    private fun fillDrawer(q: String) {
        val list = if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) }
        val showLbl = prefs.getBool("showDrawerLabels")
        val grid = FlowGrid(this, prefs.get("cols"), dp(prefs.get("iconSize")) + dp(if (showLbl) 36 else 14))
        for (a in list) grid.addView(makeCell(a, showLbl, SRC_DRAWER))
        drawerScroll.removeAllViews()
        drawerScroll.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
    }

    private fun openDrawer() {
        if (drawerOpen || shadeOpen) return
        drawerOpen = true
        root.swipeEnabled = false
        drawerSearch.setText("")
        fillDrawer("")
        drawer.visibility = View.VISIBLE
        drawer.alpha = 0f
        drawer.translationY = dp(90).toFloat()
        drawer.spring(SpringProp.TRANSLATION_Y, 0f, prefs)
        drawer.animate().alpha(1f).setDuration(prefs.ms(200)).start()
        animateDepth(0.9f, prefs.ms(300))
    }

    private fun closeDrawer(animate: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        root.swipeEnabled = true
        try {
            val imm = getSystemService(InputMethodManager::class.java)
            imm?.hideSoftInputFromWindow(drawerSearch.windowToken, 0)
        } catch (e: Exception) {
        }
        if (!animate) {
            drawer.animate().cancel()
            drawer.visibility = View.GONE
            return
        }
        drawer.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(prefs.ms(200))
            .withEndAction { drawer.visibility = View.GONE }.start()
        animateDepth(0f, prefs.ms(260))
    }

    // ------------------------------------------------------------ depth (blur + dim)

    /** t = 0: home is sharp. t = 1: home is fully blurred and dimmed. */
    private fun setDepth(t: Float) {
        depth = t
        homeLayer.setBlur(prefs.blurPx() * t)
        scrim.alpha = 0.35f * t
        try {
            if (windowManager.isCrossWindowBlurEnabled) {
                window.setBackgroundBlurRadius((prefs.blurPx() * 1.5f * t).toInt())
            }
        } catch (e: Exception) {
        }
    }

    private fun animateDepth(to: Float, ms: Long, end: (() -> Unit)? = null) {
        val a = ValueAnimator.ofFloat(depth, to)
        a.duration = ms
        a.addUpdateListener { setDepth(it.animatedValue as Float) }
        if (end != null) {
            a.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    end()
                }
            })
        }
        a.start()
    }

    // ------------------------------------------------------------ shade

    private fun openShade(qs: Boolean) {
        if (shadeOpen || drawerOpen) return
        val svc = HazelineService.instance
        if (svc != null) {
            svc.showShade(qs)
            return
        }
        shadeOpen = true
        root.swipeEnabled = false
        animateDepth(1f, prefs.ms(280))
        shade.show(qs)
    }

    private fun closeShade() {
        if (!shadeOpen) return
        val svc = HazelineService.instance
        if (svc != null && svc.isShadeShown()) {
            svc.hideShade()
            return
        }
        shadeOpen = false
        animateDepth(0f, prefs.ms(260))
        shade.hide { root.swipeEnabled = true }
    }

    // ------------------------------------------------------------ launching and returning

    private fun averageColor(b: Bitmap?): Int {
        if (b == null) return Color.DKGRAY
        val s = Bitmap.createScaledBitmap(b, 1, 1, true)
        val c = s.getPixel(0, 0)
        return Color.rgb(Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun findIconRect(pkg: String): Rect? {
        val iv = iconViews[pkg] ?: return null
        if (!iv.isAttachedToWindow || iv.width == 0) return null
        val loc = IntArray(2)
        iv.getLocationInWindow(loc)
        return Rect(loc[0], loc[1], loc[0] + iv.width, loc[1] + iv.height)
    }

    private fun launch(app: AppInfo, iv: View) {
        val loc = IntArray(2)
        iv.getLocationInWindow(loc)
        val rect = Rect(loc[0], loc[1], loc[0] + iv.width, loc[1] + iv.height)
        val pkg = app.component.packageName
        HomeBridge.lastLaunchRect[pkg] = rect
        if (drawerOpen) closeDrawer(false)
        val radius = rect.width() * prefs.get("round") / 100f
        val viaService = HazelineService.instance?.playOpen(pkg, rect, app.icon, averageColor(app.icon), radius) ?: false
        if (viaService) {
            animateDepth(0.75f, prefs.ms(340))
        } else {
            playOpen(app, rect)
        }
        val opts = ActivityOptions.makeCustomAnimation(this, R.anim.app_in, R.anim.stay).toBundle()
        awaitingReturn = true
        awaitingPkg = pkg
        try {
            launcherApps.startMainActivity(app.component, app.info.user, rect, opts)
        } catch (e: Exception) {
            awaitingReturn = false
            awaitingPkg = null
            fadeOutCard()
            animateDepth(0f, prefs.ms(200))
        }
    }

    /** Fallback card animation, used only when Hazeline Motion is switched off. */
    private fun playOpen(app: AppInfo, r: Rect) {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val startR = r.width() * prefs.get("round") / 100f
        val endR = dp(30).toFloat()
        cardBg.setColor(averageColor(app.icon))
        cardIcon.setImageBitmap(app.icon)
        card.visibility = View.VISIBLE
        card.alpha = 1f
        val lp = card.layoutParams as FrameLayout.LayoutParams

        fun frameAt(t: Float) {
            lp.width = (r.width() + (w - r.width()) * t).toInt()
            lp.height = (r.height() + (h - r.height()) * t).toInt()
            card.layoutParams = lp
            card.translationX = r.left * (1f - t)
            card.translationY = r.top * (1f - t)
            cardBg.cornerRadius = startR + (endR - startR) * t
            card.rotationX = -9f * (1f - t)
            cardIcon.alpha = (1f - t * 1.8f).coerceAtLeast(0f)
            cardIcon.scaleX = 1f + 0.5f * t
            cardIcon.scaleY = 1f + 0.5f * t
            setDepth(0.75f * t)
        }

        frameAt(0f)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = prefs.ms(340)
        a.interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
        a.addUpdateListener { frameAt(it.animatedValue as Float) }
        a.start()

        ui.postDelayed({
            if (resumed && card.visibility == View.VISIBLE) {
                awaitingReturn = false
                fadeOutCard()
                animateDepth(0f, prefs.ms(220))
            }
        }, 1600L)
    }

    private fun fadeOutCard() {
        card.animate().alpha(0f).setDuration(prefs.ms(180)).withEndAction {
            card.visibility = View.GONE
            card.rotationX = 0f
        }.start()
    }

    private fun allAnimViews(): List<View> {
        val out = ArrayList<View>()
        if (!this::pager.isInitialized) return out
        val page = pager.pageAt(pager.currentItem)
        if (page != null) {
            for (i in 0 until page.childCount) out.add(page.getChildAt(i))
        }
        for (i in 0 until dock.childCount) out.add(dock.getChildAt(i))
        return out
    }

    /**
     * Back from an app. Everything starts small, blurred and pulled toward the middle, then springs outward.
     * The icon you just closed lands first and a little bigger; labels fade in last.
     */
    private fun playReturn(pkg: String?) {
        fadeOutCard()
        val views = allAnimViews()
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val anchor = if (pkg == null) null else (findIconRect(pkg) ?: HomeBridge.lastLaunchRect[pkg])
        val ax = anchor?.exactCenterX() ?: (w / 2f)
        val ay = anchor?.exactCenterY() ?: (h / 2f)
        setDepth(1f)
        animateDepth(0f, prefs.ms(430))
        val loc = IntArray(2)
        for (v in views) {
            v.getLocationInWindow(loc)
            val cx = loc[0] + v.width / 2f - v.translationX
            val cy = loc[1] + v.height / 2f - v.translationY
            val dist = hypot(cx - ax, cy - ay)
            val delay = (dist / h * prefs.ms(240)).toLong()
            v.animate().cancel()
            val isAnchor = pkg != null && v.tag == pkg
            if (isAnchor) {
                v.scaleX = 1.3f
                v.scaleY = 1.3f
                v.translationX = 0f
                v.translationY = 0f
                v.alpha = 1f
            } else {
                v.scaleX = 0.58f
                v.scaleY = 0.58f
                v.translationX = (w / 2f - cx) * 0.30f
                v.translationY = (h / 2f - cy) * 0.30f
                v.alpha = 0f
            }
            val label = (v as? ViewGroup)?.getChildAt(1)
            if (label != null) {
                label.alpha = 0f
                label.animate().alpha(1f).setStartDelay(delay + prefs.ms(220)).setDuration(prefs.ms(200)).start()
            }
            v.spring(SpringProp.TRANSLATION_X, 0f, prefs, delay)
            v.spring(SpringProp.TRANSLATION_Y, 0f, prefs, delay)
            v.spring(SpringProp.SCALE_X, 1f, prefs, delay)
            v.spring(SpringProp.SCALE_Y, 1f, prefs, delay)
            if (!isAnchor) v.animate().alpha(1f).setStartDelay(delay).setDuration(prefs.ms(160)).start()
        }
    }

    // ------------------------------------------------------------ unlock burst

    private fun cellsReady(): Boolean = allAnimViews().isNotEmpty()

    /** Waits until the phone is really unlocked and the icons exist, then plays the burst. */
    private fun startBurstPoll() {
        if (pollingBurst) return
        pollingBurst = true
        pollTries = 0
        val tick = object : Runnable {
            override fun run() {
                if (!needBurst || !resumed || pollTries > 200) {
                    pollingBurst = false
                    if (needBurst && pollTries > 200) restoreAll()
                    return
                }
                pollTries++
                val locked = try {
                    keyguard.isKeyguardLocked
                } catch (e: Exception) {
                    false
                }
                if (!locked && cellsReady()) {
                    pollingBurst = false
                    needBurst = false
                    playBurst()
                    return
                }
                ui.postDelayed(this, 120L)
            }
        }
        ui.post(tick)
    }

    private fun restoreAll() {
        needBurst = false
        for (v in allAnimViews()) v.alpha = 1f
    }

    /** Icons fly out from the bottom centre into place, nearest first. */
    private fun playBurst() {
        val views = allAnimViews()
        if (views.isEmpty()) return
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val ox = w / 2f
        val oy = h - dp(90).toFloat()
        val loc = IntArray(2)
        setDepth(0.6f)
        animateDepth(0f, prefs.ms(650))
        for (v in views) {
            v.getLocationInWindow(loc)
            val cx = loc[0] + v.width / 2f - v.translationX
            val cy = loc[1] + v.height / 2f - v.translationY
            val dist = hypot(cx - ox, cy - oy)
            val delay = (dist / h * prefs.ms(400)).toLong()
            v.animate().cancel()
            v.translationX = ox - cx
            v.translationY = oy - cy
            v.scaleX = 0.2f
            v.scaleY = 0.2f
            v.alpha = 0f
            v.spring(SpringProp.TRANSLATION_X, 0f, prefs, delay)
            v.spring(SpringProp.TRANSLATION_Y, 0f, prefs, delay)
            v.spring(SpringProp.SCALE_X, 1f, prefs, delay)
            v.spring(SpringProp.SCALE_Y, 1f, prefs, delay)
            v.animate().alpha(1f).setStartDelay(delay).setDuration(prefs.ms(150)).start()
        }
    }

    // ------------------------------------------------------------ pinch

    private val pinchListener = object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            pinch = 1f
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            pinch = (pinch * detector.scaleFactor).coerceIn(0.82f, 1f)
            homeLayer.scaleX = pinch
            homeLayer.scaleY = pinch
            setDepth((1f - pinch) / 0.18f * 0.6f)
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            val openSettings = pinch < 0.9f
            homeLayer.spring(SpringProp.SCALE_X, 1f, prefs)
            homeLayer.spring(SpringProp.SCALE_Y, 1f, prefs)
            animateDepth(0f, prefs.ms(260))
            pinch = 1f
            if (openSettings) {
                startActivity(Intent(this@HomeActivity, SettingsActivity::class.java))
            }
        }
    }

    private val scaleDetector by lazy { ScaleGestureDetector(this, pinchListener) }
}
