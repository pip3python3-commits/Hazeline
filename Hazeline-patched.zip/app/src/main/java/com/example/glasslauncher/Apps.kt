package com.example.glasslauncher

import android.content.ComponentName
import android.content.Context
import android.content.pm.LauncherActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import java.io.File
import java.io.FileOutputStream

class AppInfo(val info: LauncherActivityInfo) {
    val label: String = info.label.toString()
    val component: ComponentName = info.componentName
    val key: String = component.flattenToString() + "#" + info.user.hashCode()
    var icon: Bitmap? = null
}

object IconRenderer {
    /** Draws an app icon into a rounded square whose roundness comes from the settings. */
    fun render(info: LauncherActivityInfo, sizePx: Int, roundPct: Int, density: Int): Bitmap {
        val d = info.getIcon(density)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            val inset = (sizePx * 0.25f).toInt()
            val l = -inset
            val t = -inset
            val r = sizePx + inset
            val b = sizePx + inset
            d.background?.let {
                it.setBounds(l, t, r, b)
                it.draw(c)
            }
            d.foreground?.let {
                it.setBounds(l, t, r, b)
                it.draw(c)
            }
        } else {
            c.drawColor(Color.WHITE)
            val pad = (sizePx * 0.14f).toInt()
            d.setBounds(pad, pad, sizePx - pad, sizePx - pad)
            d.draw(c)
        }
        val radius = sizePx * roundPct / 100f
        val path = Path()
        path.addRoundRect(RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat()), radius, radius, Path.Direction.CW)
        path.fillType = Path.FillType.INVERSE_WINDING
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        c.drawPath(path, p)
        return bmp
    }
}

/** Icons are saved to disk once, so the home screen can come up instantly next time. */
object IconCache {
    private fun file(ctx: Context, app: AppInfo, sig: String): File {
        val name = (app.component.flattenToShortString() + "_" + sig).replace(Regex("[^A-Za-z0-9._-]"), "_")
        return File(File(ctx.filesDir, "icons"), "$name.png")
    }

    /** A plain placeholder so one broken app can never leave a blank/missing icon. */
    private fun fallback(app: AppInfo, sizePx: Int, round: Int): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.parseColor("#55FFFFFF")
        val radius = sizePx * round / 100f
        c.drawRoundRect(RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat()), radius, radius, p)
        val letter = app.label.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?"
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE
        tp.textSize = sizePx * 0.46f
        tp.textAlign = Paint.Align.CENTER
        val fm = tp.fontMetrics
        c.drawText(letter, sizePx / 2f, sizePx / 2f - (fm.ascent + fm.descent) / 2f, tp)
        return bmp
    }

    /** Never throws: a single app's broken icon falls back to a letter tile instead of killing the whole load. */
    fun get(ctx: Context, app: AppInfo, px: Int, round: Int, dens: Int): Bitmap {
        return try {
            val sig = "$px-$round"
            val f = file(ctx, app, sig)
            if (f.exists()) {
                val b = BitmapFactory.decodeFile(f.path)
                if (b != null) return b
            }
            val b = IconRenderer.render(app.info, px, round, dens)
            try {
                f.parentFile?.mkdirs()
                FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (e: Exception) {
            }
            b
        } catch (e: Exception) {
            fallback(app, px, round)
        }
    }

    fun clear(ctx: Context) {
        File(ctx.filesDir, "icons").deleteRecursively()
    }
}

/** What is placed on the home screen. kind = "app" or "widget". */
class HomeItem(
    val kind: String,
    val key: String,
    var page: Int,
    var x: Int,
    var y: Int,
    var sx: Int,
    var sy: Int
)

object HomeStore {
    private const val KEY = "home_items"
    private const val SEEDED = "home_seeded"

    fun load(prefs: Prefs): MutableList<HomeItem> {
        val out = ArrayList<HomeItem>()
        for (line in prefs.getStr(KEY, "").split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("|")
            if (p.size < 7) continue
            try {
                out.add(HomeItem(p[0], p[1], p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), p[6].toInt()))
            } catch (e: Exception) {
            }
        }
        return out
    }

    fun save(prefs: Prefs, items: List<HomeItem>) {
        prefs.putStr(KEY, items.joinToString("\n") {
            listOf(it.kind, it.key, it.page, it.x, it.y, it.sx, it.sy).joinToString("|")
        })
    }

    fun seeded(prefs: Prefs): Boolean = prefs.getStr(SEEDED, "") == "1"

    fun markSeeded(prefs: Prefs) {
        prefs.putStr(SEEDED, "1")
    }
}
