package com.example.glasslauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.abs
import kotlin.math.min

/** Root layout: catches a swipe up or down anywhere on the home screen. */
class GestureFrame(ctx: Context) : FrameLayout(ctx) {
    var swipeEnabled = true
    var onSwipeDown: (() -> Unit)? = null
    var onSwipeUp: (() -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var tracking = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (!swipeEnabled) return false
        if (e.pointerCount > 1) {
            tracking = false
            return false
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                tracking = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (tracking) {
                    val dy = e.y - downY
                    val dx = e.x - downX
                    if (abs(dy) > slop * 2 && abs(dy) > abs(dx) * 1.5f) {
                        tracking = false
                        if (dy > 0) onSwipeDown?.invoke() else onSwipeUp?.invoke()
                        return true
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> tracking = false
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = true
}

/** One home-screen page. Children sit on a cols x rows grid and may span several cells (widgets). */
class GridPage(ctx: Context, val cols: Int, val rows: Int) : ViewGroup(ctx) {

    class Lp(val cx: Int, val cy: Int, val sx: Int = 1, val sy: Int = 1) :
        ViewGroup.LayoutParams(WRAP, WRAP)

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is Lp

    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = Lp(0, 0)

    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = Lp(0, 0)

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val cw = w / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as Lp
            c.measure(
                MeasureSpec.makeMeasureSpec(cw * lp.sx, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch * lp.sy, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        val ch = (b - t) / rows
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as Lp
            val x = lp.cx * cw
            val y = lp.cy * ch
            c.layout(x, y, x + cw * lp.sx, y + ch * lp.sy)
        }
    }
}

/** App drawer grid: fixed row height, as many rows as needed (lives inside a ScrollView). */
class FlowGrid(ctx: Context, private val cols: Int, private val cellH: Int) : ViewGroup(ctx) {

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val rows = (childCount + cols - 1) / cols
        setMeasuredDimension(w, rows * cellH)
        val cw = w / cols
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        for (i in 0 until childCount) {
            val x = (i % cols) * cw
            val y = (i / cols) * cellH
            getChildAt(i).layout(x, y, x + cw, y + cellH)
        }
    }
}


/** Lightweight horizontal pager used by the launcher without relying on RecyclerView internals. */
class HomePager(ctx: Context) : android.widget.HorizontalScrollView(ctx) {
    var onScrollProgress: ((Float) -> Unit)? = null
    private val strip = android.widget.LinearLayout(ctx).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL
        clipChildren = false
        clipToPadding = false
    }
    private var pages: List<GridPage> = emptyList()
    private var pendingPage = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        clipChildren = false
        clipToPadding = false
        addView(strip, android.widget.HorizontalScrollView.LayoutParams(
            android.widget.HorizontalScrollView.LayoutParams.WRAP_CONTENT,
            android.widget.HorizontalScrollView.LayoutParams.MATCH_PARENT
        ))
    }

    val currentItem: Int
        get() = if (width <= 0) pendingPage.coerceAtLeast(0)
        else (scrollX.toFloat() / width).toInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))

    fun setPages(newPages: List<GridPage>, initialPage: Int) {
        pages = newPages
        pendingPage = initialPage.coerceIn(0, (newPages.size - 1).coerceAtLeast(0))
        strip.removeAllViews()
        for (page in newPages) {
            strip.addView(page, android.widget.LinearLayout.LayoutParams(
                width.coerceAtLeast(1), android.widget.LinearLayout.LayoutParams.MATCH_PARENT
            ))
        }
        requestLayout()
        post { scrollTo((pendingPage * width).coerceAtLeast(0), 0); emitProgress() }
    }

    fun pageAt(index: Int): GridPage? = pages.getOrNull(index)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        for (i in 0 until strip.childCount) {
            val child = strip.getChildAt(i)
            val lp = child.layoutParams as android.widget.LinearLayout.LayoutParams
            if (lp.width != w) { lp.width = w; child.layoutParams = lp }
        }
        scrollTo((pendingPage * w).coerceAtLeast(0), 0)
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) pendingPage = currentItem
        emitProgress()
    }

    private fun emitProgress() {
        if (width > 0) onScrollProgress?.invoke(scrollX.toFloat() / width)
    }
}

class DotsView(ctx: Context) : View(ctx) {
    var count = 0
        set(v) {
            field = v
            invalidate()
        }
    var index = 0f
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        if (count < 2) return
        val r = height * 0.18f
        val gap = r * 4.5f
        val start = width / 2f - (count - 1) * gap / 2f
        for (i in 0 until count) {
            val a = 1f - min(1f, abs(i - index))
            p.color = Color.WHITE
            p.alpha = (110 + 145 * a).toInt()
            c.drawCircle(start + i * gap, height / 2f, r * (1f + 0.35f * a), p)
        }
    }
}

/** Pill-shaped slider like the brightness / volume bars in the control panel. */
class PillSlider(ctx: Context, iconRes: Int) : View(ctx) {
    var onChange: ((Float) -> Unit)? = null
    var onLongPress: (() -> Unit)? = null
    private val longPressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var longPressFired = false
    private var downX = 0f
    private val longPressTask = Runnable {
        longPressFired = true
        onLongPress?.invoke()
    }
    var progress = 0.5f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = ctx.getDrawable(iconRes)?.mutate()
    private val clip = Path()
    private val rect = RectF()

    init {
        track.color = Color.parseColor("#44FFFFFF")
        fill.color = Color.parseColor("#F2FFFFFF")
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, track)
        c.save()
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clip)
        c.drawRect(0f, 0f, w * progress, h, fill)
        c.restore()
        icon?.let {
            val s = (h * 0.45f).toInt()
            val left = (h * 0.32f).toInt()
            val top = ((h - s) / 2f).toInt()
            it.setBounds(left, top, left + s, top + s)
            it.setTint(if (w * progress > left + s) Color.parseColor("#1B1B1F") else Color.WHITE)
            it.draw(c)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x
                longPressFired = false
                longPressHandler.removeCallbacks(longPressTask)
                if (onLongPress != null) longPressHandler.postDelayed(longPressTask, ViewConfiguration.getLongPressTimeout().toLong())
                update(e.x)
            }
            MotionEvent.ACTION_MOVE -> {
                if (kotlin.math.abs(e.x - downX) > ViewConfiguration.get(context).scaledTouchSlop) {
                    longPressHandler.removeCallbacks(longPressTask)
                }
                update(e.x)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                longPressHandler.removeCallbacks(longPressTask)
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun update(x: Float) {
        progress = x / width
        onChange?.invoke(progress)
    }
}

/** Round glass button with an icon. White when active. */
class Toggle(ctx: Context, icon: Int, private val sizeDp: Int) : FrameLayout(ctx) {
    private val bg = GradientDrawable()
    private val iv = ImageView(ctx)
    var active = false
        set(v) {
            field = v
            refresh()
        }

    init {
        bg.shape = GradientDrawable.OVAL
        background = bg
        iv.setImageResource(icon)
        val s = (sizeDp * 0.5f * resources.displayMetrics.density).toInt()
        addView(iv, FrameLayout.LayoutParams(s, s, Gravity.CENTER))
        refresh()
    }

    private fun refresh() {
        bg.setColor(Color.parseColor(if (active) "#F2FFFFFF" else "#44000000"))
        iv.imageTintList = ColorStateList.valueOf(Color.parseColor(if (active) "#1B1B1F" else "#FFFFFF"))
    }
}
