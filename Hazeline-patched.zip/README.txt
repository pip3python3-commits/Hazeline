Hazeline Launcher — GitHub build package

Build an installable debug APK
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open Actions and run “Build Hazeline APK” (or push a commit).
3. Open the completed workflow run and download the “hazeline-debug-apk” artifact.
4. Extract the artifact and install app-debug.apk on an Android 12+ device (minSdk 31).

The workflow installs JDK 17, Gradle 8.9, Android platform 35 and build-tools 35.0.0, then runs :app:assembleDebug.
The build is not considered verified until that GitHub Actions job succeeds. This package was integrated and statically checked here, but this environment does not have an Android SDK / Gradle installation available for a local Android build or device testing.

Integrated changes in this package
- Newest supplied HomeActivity.kt, Prefs.kt, Fx.kt, Apps.kt and HazelineService.kt.
- A HomePager implementation for the new HomeActivity, including current-page retention and scroll-progress reporting.
- Compatibility between the new preference names and the existing SettingsActivity keys/API.
- ShadeView spring calls updated to use the no-AndroidX SpringProp API in the supplied Fx.kt.
- Home icon cache keys include Android user identity, with legacy saved home-item key compatibility.
- Widget resize dialog, home-page management, icon label preferences, resilient icon fallback, shade-state synchronization, long-press expanded sliders, bundled default wallpaper, and GitHub Actions APK packaging.

Known verification limit
The CI workflow must still run to confirm Kotlin/resource compilation. Test on-device after a successful build, especially accessibility overlay attachment/detachment, shade back handling, widget provider resize behavior, and wallpaper permission/OEM behavior.
