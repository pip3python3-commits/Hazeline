package com.example.glasslauncher

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Hazeline Motion. Turned on in Accessibility settings. It does three things:
 *  1. Covers the top edge of the screen so a swipe down opens Hazeline's panel instead of Samsung's.
 *  2. Keeps a recent picture of the app you are using.
 *  3. Draws app open / close animations in a window above everything, so the system's own animation is hidden.
 */
class HazelineService : AccessibilityService() {

    companion object {
        var instance: HazelineService? = null

        /** The home screen listens so it can blur itself while the panel is open. */
        var depthListener: ((Float) -> Unit)? = null

        /** The home screen listens so its own shadeOpen flag (back button, gestures) stays true. */
        var shadeShownListener: ((Boolean) -> Unit)? = null

        private val DENY = setOf(
            "com.android.systemui",
            "android",
            "com.google.android.inputmethod.latin",
            "com.samsung.android.honeyboard",
            "com.samsung.android.app.cocktailbarservice",
            "com.samsung.android.app.taskedge"
        )
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private val km by lazy { getSystemService(KeyguardManager::class.java)!! }

    private var strip: View? = null
    private var shadeRoot: FrameLayout? = null
    private var shadeScrim: View? = null
    private var shade: ShadeView? = null
    private var shadeShown = false
    private var shadeDepth = 0f

    private var motion: MotionOverlay? = null
    private var foregroundPkg: String? = null
    private var captureJob: Runnable? = null
    private var pendingOpen: String? = null
    private var openAnimDone = false
    private var openAppShown = false

    private var downX = 0f
    private var downY = 0f
    private var stripTracking = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            refreshStrip()
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WindowManager::class.java)!!
        prefs = Prefs(this)
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        refreshStrip()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    private fun cleanup() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
        }
        removeStrip()
        removeMotion()
        shadeRoot?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        shadeShown = false
        shadeDetaching = false
        instance = null
    }

    // ------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sysDimen(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun overlayParams(h: Int, flags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            MATCH, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        return lp
    }

    // ------------------------------------------------------------ top-edge strip

    private fun refreshStrip() {
        val locked = try {
            km.isKeyguardLocked
        } catch (e: Exception) {
            false
        }
        if (locked) removeStrip() else addStrip()
    }

    private fun addStrip() {
        if (strip != null) return
        val v = View(this)
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    stripTracking = true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (stripTracking) {
                        val dy = e.rawY - downY
                        val dx = e.rawX - downX
                        if (dy > dp(12) && dy > abs(dx)) {
                            stripTracking = false
                            val right = downX > resources.displayMetrics.widthPixels / 2f
                            showShade(right)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stripTracking = false
            }
            true
        }
        val h = sysDimen("status_bar_height").coerceAtLeast(dp(24))
        val lp = overlayParams(
            h,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )
        try {
            wm.addView(v, lp)
            strip = v
        } catch (e: Exception) {
        }
    }

    private fun removeStrip() {
        strip?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        strip = null
    }

    // ------------------------------------------------------------ the panel

    private fun ensureShade() {
        if (shade != null) return
        val root = FrameLayout(this)
        val scrim = View(this)
        scrim.setBackgroundColor(Color.BLACK)
        scrim.alpha = 0f
        val sv = ShadeView(this, prefs, object : ShadeView.Host {
            override fun close() {
                hideShade()
            }

            override fun settings() {
                hideShade()
                val i = Intent(this@HazelineService, SettingsActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        })
        sv.setInsets(sysDimen("status_bar_height"), sysDimen("navigation_bar_height"))
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        shadeRoot = root
        shadeScrim = scrim
        shade = sv
    }

    /** True from the moment a hide starts until the window is actually detached. */
    private var shadeDetaching = false

    fun showShade(qs: Boolean) {
        if (shadeShown) return
        ensureShade()
        val root = shadeRoot ?: return
        val sv = shade ?: return
        // A previous hide() may still be mid-animation with the window still attached.
        // Clear it synchronously so we never try to add an already-attached view.
        if (shadeDetaching || root.isAttachedToWindow) {
            try {
                wm.removeViewImmediate(root)
            } catch (e: Exception) {
            }
            shadeDetaching = false
        }
        val lp = overlayParams(MATCH, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        try {
            if (wm.isCrossWindowBlurEnabled) {
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                lp.blurBehindRadius = (prefs.blurPx() * 1.6f).toInt()
            }
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        shadeShown = true
        shadeShownListener?.invoke(true)
        shadeScrim?.animate()?.alpha(0.3f)?.setDuration(prefs.ms(260))?.start()
        animateShadeDepth(1f, prefs.ms(280))
        sv.show(qs)
    }

    fun hideShade() {
        if (!shadeShown) return
        shadeShown = false
        shadeShownListener?.invoke(false)
        shadeDetaching = true
        shadeScrim?.animate()?.alpha(0f)?.setDuration(prefs.ms(220))?.start()
        animateShadeDepth(0f, prefs.ms(260))
        shade?.hide {
            shadeRoot?.let {
                try {
                    wm.removeView(it)
                } catch (e: Exception) {
                }
            }
            shadeDetaching = false
        }
    }

    /** Whether the service-rendered panel is currently up (so the Activity can mirror it). */
    fun isShadeShown(): Boolean = shadeShown

    /** The service-owned panel instance, if one has been built yet. */
    fun shadeView(): ShadeView? = shade

    private fun animateShadeDepth(to: Float, ms: Long) {
        val a = ValueAnimator.ofFloat(shadeDepth, to)
        a.duration = ms
        a.addUpdateListener {
            shadeDepth = it.animatedValue as Float
            depthListener?.invoke(shadeDepth)
        }
        a.start()
    }

    // ------------------------------------------------------------ what app is on screen

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        val cls = e.className?.toString() ?: ""
        refreshStrip()
        if (pkg == packageName) {
            if (cls.endsWith("HomeActivity")) onHomeShown()
            return
        }
        if (pkg in DENY || cls.startsWith("android.widget.") || cls.startsWith("android.view.")) return
        onAppShown(pkg)
    }

    private fun onAppShown(pkg: String) {
        if (shadeShown) hideShade()
        foregroundPkg = pkg
        if (pendingOpen == pkg) {
            openAppShown = true
            val ov = motion
            if (openAnimDone && ov != null) fadeOutMotion(ov)
        }
        scheduleCapture(pkg, 600L)
    }

    private fun onHomeShown() {
        if (shadeShown) hideShade()
        captureJob?.let { ui.removeCallbacks(it) }
        val left = foregroundPkg
        foregroundPkg = null
        if (left != null && pendingOpen == null) playClose(left)
    }

    // ------------------------------------------------------------ snapshots

    private fun scheduleCapture(pkg: String, delay: Long) {
        captureJob?.let { ui.removeCallbacks(it) }
        val job = Runnable { capture(pkg) }
        captureJob = job
        ui.postDelayed(job, delay)
    }

    private fun capture(pkg: String) {
        if (foregroundPkg != pkg || shadeShown || motion != null) {
            if (foregroundPkg == pkg) scheduleCapture(pkg, 2500L)
            return
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        if (hw != null) {
                            val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                            if (soft != null) {
                                val small = Bitmap.createScaledBitmap(soft, soft.width / 3, soft.height / 3, true)
                                SnapshotStore.put(pkg, small)
                                if (small !== soft) soft.recycle()
                            }
                            hw.recycle()
                        }
                        result.hardwareBuffer.close()
                    } catch (e: Exception) {
                    }
                    if (foregroundPkg == pkg) scheduleCapture(pkg, 2500L)
                }

                override fun onFailure(errorCode: Int) {
                    if (foregroundPkg == pkg) scheduleCapture(pkg, 3000L)
                }
            })
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ app open / close animation

    private fun newOverlay(): MotionOverlay? {
        val v = MotionOverlay(this)
        val lp = overlayParams(
            MATCH,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        )
        return try {
            wm.addView(v, lp)
            v
        } catch (e: Exception) {
            null
        }
    }

    private fun removeMotion() {
        motion?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        motion = null
        pendingOpen = null
    }

    private fun fadeOutMotion(ov: MotionOverlay) {
        ov.animate().alpha(0f).setDuration(prefs.ms(170)).withEndAction {
            if (motion === ov) removeMotion()
        }.start()
    }

    /** The home screen calls this when you tap an icon. Returns false if the service is not ready. */
    fun playOpen(pkg: String, rect: Rect, icon: Bitmap?, color: Int, iconRadius: Float): Boolean {
        removeMotion()
        val ov = newOverlay() ?: return false
        motion = ov
        pendingOpen = pkg
        openAnimDone = false
        openAppShown = false
        ov.snapshot = SnapshotStore.get(pkg)
        ov.icon = icon
        ov.color = color
        ov.iconRect = RectF(rect)
        ov.radiusIcon = iconRadius
        ov.radiusScreen = dp(30).toFloat()
        ov.t = 1f
        val a = ValueAnimator.ofFloat(1f, 0f)
        a.duration = prefs.ms(380)
        a.interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
        a.addUpdateListener { ov.t = it.animatedValue as Float }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                openAnimDone = true
                if (openAppShown && motion === ov) fadeOutMotion(ov)
            }
        })
        a.start()
        // never leave the cover up if the app does not appear
        ui.postDelayed({
            if (motion === ov) fadeOutMotion(ov)
        }, prefs.ms(380) + 1500L)
        return true
    }

    private fun playClose(pkg: String) {
        val snap = SnapshotStore.get(pkg) ?: return
        removeMotion()
        val ov = newOverlay() ?: return
        motion = ov
        val dm = resources.displayMetrics
        val r = HomeBridge.iconRect?.invoke(pkg)
            ?: HomeBridge.lastLaunchRect[pkg]
            ?: Rect(
                dm.widthPixels / 2 - dp(28), dm.heightPixels - dp(220),
                dm.widthPixels / 2 + dp(28), dm.heightPixels - dp(164)
            )
        ov.snapshot = snap
        ov.iconRect = RectF(r)
        ov.radiusIcon = r.width() * prefs.get("round") / 100f
        ov.radiusScreen = dp(30).toFloat()
        ov.t = 0f
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = prefs.ms(400)
        a.interpolator = PathInterpolator(0.3f, 0f, 0.15f, 1f)
        a.addUpdateListener {
            val v = it.animatedValue as Float
            ov.t = v
            ov.alpha = if (v > 0.78f) 1f - (v - 0.78f) / 0.22f else 1f
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (motion === ov) removeMotion()
            }
        })
        a.start()
    }
}
