package com.example.glasslauncher

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val prefs = Prefs(this)
        val density = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(40))

        val title = TextView(this)
        title.text = "Launcher settings"
        title.textSize = 24f
        title.setTextColor(Color.WHITE)
        title.setTypeface(title.typeface, Typeface.BOLD)
        col.addView(title)

        val note = TextView(this)
        note.text = "Appearance, grid, icon size and roundness settings apply as you use the launcher or return Home."
        note.textSize = 13f
        note.setTextColor(Color.parseColor("#AAFFFFFF"))
        note.setPadding(0, dp(6), 0, 0)
        col.addView(note)

        val labelsTitle = TextView(this).apply {
            text = "Home screen appearance"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(24), 0, dp(4))
        }
        col.addView(labelsTitle)
        fun boolSetting(key: String, text: String) {
            val check = CheckBox(this).apply {
                this.text = text
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                isChecked = prefs.getBool(key)
                setOnCheckedChangeListener { _, checked -> prefs.putBool(key, checked) }
            }
            col.addView(check)
        }
        boolSetting("showHomeLabels", "Show app names on Home")
        boolSetting("showDrawerLabels", "Show app names in app drawer")

        for (s in Prefs.ALL) {
            val label = TextView(this)
            label.setTextColor(Color.WHITE)
            label.textSize = 15f
            label.setPadding(0, dp(22), 0, 0)
            label.text = s.label + ": " + prefs.get(s.key) + s.unit

            val bar = SeekBar(this)
            bar.max = s.max - s.min
            bar.progress = prefs.get(s.key) - s.min
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + s.min
                    prefs.put(s.key, v)
                    label.text = s.label + ": " + v + s.unit
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}

                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            col.addView(label)
            col.addView(bar)
        }

        fun button(text: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = text
            b.setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(MATCH, WRAP)
            p.topMargin = dp(16)
            col.addView(b, p)
        }
        val status = TextView(this)
        status.textSize = 13f
        status.setTextColor(Color.parseColor("#CCFFFFFF"))
        status.setPadding(0, dp(26), 0, 0)
        status.text = if (HazelineService.instance != null) {
            "Hazeline Motion is ON: your panel replaces Samsung's, and app animations are active."
        } else {
            "Hazeline Motion is OFF. Turn it on to replace Samsung's pull-down panel and get the app animations."
        }
        col.addView(status)
        button("Turn on Hazeline Motion") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("Set as default home app") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        button("Allow notification access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("Remove Samsung's app animations (needs one-time setup)") {
            try {
                val now = Settings.Global.getFloat(contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f)
                val next = if (now > 0f) 0f else 1f
                Settings.Global.putFloat(contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, next)
                Toast.makeText(this, if (next == 0f) "System app animations off" else "System app animations back on", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Needs a one-time permission. See README.txt (adb command).",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        button("Reset sliders to defaults") {
            prefs.reset()
            recreate()
        }

        val scroll = ScrollView(this)
        scroll.addView(col)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom)
            insets
        }
        setContentView(scroll)
    }
}
